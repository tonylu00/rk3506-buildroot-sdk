#pragma once

#define SPECIAL_MAGIC_DEFINE 42

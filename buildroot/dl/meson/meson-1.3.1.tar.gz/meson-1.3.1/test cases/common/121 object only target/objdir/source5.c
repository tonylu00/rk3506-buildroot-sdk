int func5_in_obj(void) {
    return 0;
}

# SPDX-License-Identifier: MIT

"""
legacy - Example legacy package
"""
__version__ = '1.0.0'

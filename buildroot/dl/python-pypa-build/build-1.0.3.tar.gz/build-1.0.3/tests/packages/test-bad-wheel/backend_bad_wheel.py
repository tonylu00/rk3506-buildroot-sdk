# SPDX-License-Identifier: MIT

from setuptools.build_meta import build_sdist as build_sdist


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    return 'not a wheel'

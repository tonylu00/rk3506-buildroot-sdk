// TODO(b/63135587) remove this file after the transitive dependency
// from private/android_filesystem_config.h is resolved. All files that use
// libcutils/include/private/fs_config.h should include the file directly, not
// indirectly via private/android_filesystem_config.h.
